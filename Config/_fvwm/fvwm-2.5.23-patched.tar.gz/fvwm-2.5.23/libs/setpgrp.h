/* -*-c-*- */

#ifndef SETPGRP_H
#define SETPGRP_H

int fvwm_setpgrp(void);

#endif /* SETPGRP_H */
