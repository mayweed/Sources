/* -*-c-*- */
#ifndef _EXPAND_H
#define _EXPAND_H

char *recursive_replace (GtkWidget *d, char *val);

#endif /* _EXPAND_H */
