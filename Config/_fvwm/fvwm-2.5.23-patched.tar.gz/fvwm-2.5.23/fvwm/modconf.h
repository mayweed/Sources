/* -*-c-*- */

#ifndef MODCONF_H
#define MODCONF_H


void ModuleConfig(char *action);

#endif /* MODCONF_H */
